import os
from pydantic_ai import Agent, RunContext
from pydantic_ai.tools import Tool
import os as _os

# 👉 сложи твоя ключ тук
os.environ["ANTHROPIC_API_KEY"] = "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"

# ---------- FUNCTIONS ----------

def list_dir(ctx: RunContext, path: str = ".") -> list[str]:
    try:
        return _os.listdir(path)
    except Exception as e:
        return [str(e)]

def read_file(ctx: RunContext, path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        return str(e)

def write_file(ctx: RunContext, path: str, content: str) -> str:
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return "OK"
    except Exception as e:
        return str(e)

# ---------- TOOLS ----------

tools = [
    Tool(list_dir),
    Tool(read_file),
    Tool(write_file),
]

# ---------- AGENT ----------

agent = Agent(
    "anthropic:claude-3-5-sonnet",
    tools=tools,
    system_prompt="""
Ти си AI code reviewer.
Анализирай проекта и дай:
- проблеми в кода
- предложения за подобрение
- по-добър вариант (ако трябва)

Бъди кратък и ясен.
"""
)

# ---------- RUN ----------

result = agent.run_sync("Прегледай файловете в текущата директория.")
print(result)